﻿var 
  assert = require('assert'),
  ok = assert.ok;

var 
  l = 100000, v, raw, buf, converted;
  
buf = new TubBuffer(l);
for (let i = 0; i<l; i++){
   buf[i] = i % 255;
}

for (let i = 0; i<l; i++){
   v = buf[i];
   ok(v === i % 255, 'get ' + v + ' but put ' + i % 255);
}

//CP 1251
raw = [0xCF, 0xF0, 0xE8, 0xE2, 0xE5, 0xF2, 0x21];
buf = new TubBuffer(raw.length);
for (let i=0; i<raw.length; i++){
  buf[i] = raw[i];
}
converted = buf.decodeFrom(1251); 
ok(converted === 'Привет!', 'Must be "Привет!"' + ' but got ' + converted);

//CP 866
raw = [0x8F, 0xE0, 0xA8, 0xA2, 0xA5, 0xE2, 0x21];   
for(let i=0; i<100; i++){
    buf = new TubBuffer(raw.length);
    for (let i=0; i<raw.length; i++){
      buf[i] = raw[i];
    }
    converted = buf.decodeFrom(866); 
    ok(converted === 'Привет!', 'Must be "Привет!"' + ' but got ' + converted);
}

var zipR = new TubZipReader('D:\\SVN\\M3\\trunk\\06-Source\\models\\UB\\_autotest\\_autotest.zip'); 
zipR.fileNames()